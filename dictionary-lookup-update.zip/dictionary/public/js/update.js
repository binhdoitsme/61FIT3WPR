function showUpdateResult(response) {
    const resultView = formUpdate.querySelector('#result');
    resultView.textContent = response.message;
}

function onUpdateSuccess(response) {
    response.json().then(showUpdateResult);
}

function onUpdate(event) {
    event.preventDefault();
    
    const wordInput = formUpdate.querySelector('#word');
    const definitionInput = formUpdate.querySelector('#definition');

    const word = encodeURI(wordInput.value);
    const definition = encodeURI(definitionInput.value);

    fetch(`/update?word=${word}&definition=${definition}`).then(onUpdateSuccess);
}

const formUpdate = document.querySelector('#form-update');
formUpdate.addEventListener('submit', onUpdate);