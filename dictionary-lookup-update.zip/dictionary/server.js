const express = require('express');

// dictionary
let DICTIONARY = {
    'dog': 'friend',
    'cat': 'boss'
};

const app = express();

// serve static files
app.use(express.static('tut06/solution/dictionary/public'));

app.get('/hello-world', function (req, res){
    res.end('Hello World!');
});
// test url: http://localhost:8080/hello-world

app.get('/hello', function (req, res){
    const name = req.query.name;

    res.end('Hello '+name+'!');
});
// test url: http://localhost:8080/hello?name=Cong

// === Ex 1
// app.get('/lookup', function(req, res){
//     const key = req.query.key;
//     const definition = DICTIONARY[key];

//     res.end(definition);
// });
app.get('/lookup', function (req, res) {
    const key = req.query.key;
    const definition = DICTIONARY[key];

    const response = {
        word: key,
        definition: definition
    };

    res.json(response);
});
// test url: http://localhost:8080/lookup?key=여자

// === Ex 3
app.get('/update', function (req, res){
    const word = decodeURI(req.query.word);
    const definition = decodeURI(req.query.definition);

    // update word in dictionary - add if not existed
    DICTIONARY[word] = definition;

    const response = {
        message: `Updated word: ${word}`
    };

    res.json(response);
});

app.listen(8080, function (){
    console.log('Server started listening on port 8080!');
});