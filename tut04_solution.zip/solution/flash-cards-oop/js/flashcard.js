class FlashCard {
    constructor(flashCardContainer, word, definition) {
        this.flashCardContainer = flashCardContainer;
        this.word = word;
        this.definition = definition;

        // bind events
        this._flip = this._flip.bind(this);

        this._fillContainer();
    }

    _fillContainer() {
        this.card = document.createElement('div');
        this.card.classList.add('flashcard-box');
        this.card.classList.add('show-word');
        this.card.classList.add('hidden');
        this.card.addEventListener('click', this._flip);

        const wordSide = document.createElement('div');
        wordSide.classList.add('flashcard');
        wordSide.classList.add('word');
        wordSide.textContent = this.word;

        const definitionSide = document.createElement('div');
        definitionSide.classList.add('flashcard');
        definitionSide.classList.add('definition');
        definitionSide.textContent = this.definition;

        this.card.appendChild(wordSide);
        this.card.appendChild(definitionSide);

        this.flashCardContainer.appendChild(this.card);
    }

    _flip() {
        this.card.classList.toggle('show-word');
    }

    show() {
        this.card.classList.remove('hidden');
    }

    hide() {
        this.card.classList.add('hidden');
    }
}