class StatusBar {
    constructor(statusBarContainer, maxIndex) {
        this.statusBarContainer = statusBarContainer;
        this.maxIndex = maxIndex;

        // bind events
        this._onBtnPrevClick = this._onBtnPrevClick.bind(this);
        this._onBtnNextClick = this._onBtnNextClick.bind(this);

        this._fillContainer();

        this.currentIndex = 1; // range from [1 - maxIndex]
        this._showCurrentIndex();
    }

    _fillContainer() {
        // button prev
        this.btnPrev = document.createElement('button');
        this.btnPrev.innerHTML = '&larr;';
        this.btnPrev.addEventListener('click', this._onBtnPrevClick);
        this.statusBarContainer.appendChild(this.btnPrev);

        // strong current index
        this.lblCurrentIndex = document.createElement('strong');
        this.statusBarContainer.appendChild(this.lblCurrentIndex);

        // separator
        this.statusBarContainer.appendChild(document.createTextNode('/'));

        // span number of words
        this.lblMaxIndex = document.createElement('span');
        this.lblMaxIndex.textContent = this.maxIndex;
        this.statusBarContainer.appendChild(this.lblMaxIndex);

        // button next
        this.btnNext = document.createElement('button');
        this.btnNext.innerHTML = '&rarr;';
        this.btnNext.addEventListener('click', this._onBtnNextClick);
        this.statusBarContainer.appendChild(this.btnNext);
    }

    _onBtnPrevClick() {
        if (this.currentIndex > 1) {
            this.currentIndex--;
            this._showCurrentIndex();

            document.dispatchEvent(new CustomEvent('prev-clicked'));
        }
    }

    _onBtnNextClick() {
        if (this.currentIndex < this.maxIndex) {
            this.currentIndex++;
            this._showCurrentIndex();

            document.dispatchEvent(new CustomEvent('next-clicked'));
        }
    }

    _showCurrentIndex() {
        this.lblCurrentIndex.textContent = this.currentIndex;

        if (this.currentIndex === 1) {
            this.btnPrev.disabled = true;
        } else {
            this.btnPrev.disabled = false;
        }

        if (this.currentIndex === this.maxIndex) {
            this.btnNext.disabled = true;
        } else {
            this.btnNext.disabled = false;
        }
    }
}