function createCard(word, definition) {
    const card = document.createElement('div');
    card.classList.add('flashcard-box');
    card.classList.add('show-word');
    card.classList.add('hidden');

    const wordSide = document.createElement('div');
    wordSide.classList.add('flashcard');
    wordSide.classList.add('word');
    wordSide.textContent = word;

    const definitionSide = document.createElement('div');
    definitionSide.classList.add('flashcard');
    definitionSide.classList.add('definition');
    definitionSide.textContent = definition;

    card.appendChild(wordSide);
    card.appendChild(definitionSide);

    return card;
}

function flipCard() {
    card.classList.toggle('show-word');
}

function prevCard() {
    const prevCard = card.previousElementSibling; // get prev card

    if (prevCard) { // if prev card exists
        // hide current card
        card.classList.add('hidden');

        // show prev card
        prevCard.classList.remove('hidden');

        // update status index
        currentIndex--;
        statusIndex.textContent = currentIndex;

        btnNext.disabled = false; // enable button next
        if (currentIndex === 1) { // if first word
            btnPrev.disabled = true; // disable button prev
        }

        // update card to be current card
        card = prevCard;
    }
}

function nextCard() {
    const nextCard = card.nextElementSibling; // get next card

    if (nextCard) { // if next card exists
        // hide current card
        card.classList.add('hidden');

        // show next card
        nextCard.classList.remove('hidden');

        // update status index
        currentIndex++;
        statusIndex.textContent = currentIndex;

        btnPrev.disabled = false; // enable button prev
        if (currentIndex === numOfWords) { // if last word
            btnNext.disabled = true; // disable button next
        }

        // update card to be current card
        card = nextCard;
    }
}

function navigateCards(event) {
    const key = event.key;
    if (key === 'ArrowLeft') {
        prevCard();
    } else if (key === 'ArrowRight') {
        nextCard();
    } else if (key === 'ArrowUp') {
        flipCard();
    }
}

const cardContainer = document.querySelector('#flashcard-container');

// populate words
let numOfWords = 0;
for (const word in KOREAN) {
    const card = createCard(word, KOREAN[word]);

    card.addEventListener('click', flipCard);

    cardContainer.appendChild(card);
    numOfWords++;
}

// on start: show first word
let card = cardContainer.querySelector('.flashcard-box');
card.classList.remove('hidden');

let currentIndex = 1;
const statusIndex = document.querySelector('.status strong');
statusIndex.textContent = currentIndex;
const statusTotal = document.querySelector('.status span');
statusTotal.textContent = numOfWords;

// navigate cards: mouse click
const btnPrev = document.querySelector('#btn-prev');
btnPrev.addEventListener('click', prevCard);

const btnNext = document.querySelector('#btn-next');
btnNext.addEventListener('click', nextCard);

// navigate cards: keyboard
document.addEventListener('keydown', navigateCards);