function createCard(word, definition) {
    const card = document.createElement('div');
    card.classList.add('flashcard-box');
    card.classList.add('show-word');
    card.classList.add('hidden');

    const wordSide = document.createElement('div');
    wordSide.classList.add('flashcard');
    wordSide.classList.add('word');
    wordSide.textContent = word;

    const definitionSide = document.createElement('div');
    definitionSide.classList.add('flashcard');
    definitionSide.classList.add('definition');
    definitionSide.textContent = definition;

    card.appendChild(wordSide);
    card.appendChild(definitionSide);

    return card;
}

function flipCard() {
    const card = event.currentTarget;
    card.classList.toggle('show-word');
}

const cardContainer = document.querySelector('#flashcard-container');

// populate words
let numOfWords = 0;
for (const word in KOREAN) {
    const card = createCard(word, KOREAN[word]);

    card.addEventListener('click', flipCard);
    
    cardContainer.appendChild(card);
    numOfWords++;
}

// on start: show first word
currentIndex = 1;

const card = cardContainer.querySelector('.flashcard-box');
card.classList.remove('hidden');

const statusIndex = document.querySelector('.status strong');
statusIndex.textContent = currentIndex;
const statusTotal = document.querySelector('.status span');
statusTotal.textContent = numOfWords;
