const express = require('express');

// dictionary
const DICTIONARY = {
    'dog': 'friend',
    'cat': 'boss'
};

const app = express();

// serve static files
app.use(express.static('tut06/solution/express-server/public'));

app.get('/hello-world', function (req, res){
    res.end('Hello World!');
});
// test url: http://localhost:8080/hello-world

app.get('/hello', function (req, res){
    const name = req.query.name;

    res.end('Hello '+name+'!');
});
// test url: http://localhost:8080/hello?name=Cong

app.get('/lookup', function(req, res){
    const key = req.query.key;
    const definition = DICTIONARY[key];

    res.end(definition);
});
// test url: http://localhost:8080/lookup?key=여자

app.listen(8080, function (){
    console.log('Server started listening on port 8080!');
});