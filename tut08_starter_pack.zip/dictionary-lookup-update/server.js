const express = require('express');

// dictionary
let DICTIONARY = {
    'dog': 'friend',
    'cat': 'boss'
};

const app = express();

// ====== Ex2: use json body parser (instead of body-parser)
app.use(express.urlencoded()); // submit form data
app.use(express.json()); // submit json with fetch

// serve static files
app.use(express.static('public'));

app.get('/hello-world', function (req, res) {
    res.end('Hello World!');
});
// test url: http://localhost:8080/hello-world

app.get('/hello', function (req, res) {
    const name = req.query.name;

    res.end('Hello ' + name + '!');
});
// test url: http://localhost:8080/hello?name=Cong

// ====== Ex2: query param -> route param
// app.get('/lookup', function (req, res) {
//     const key = req.query.key;
//     const definition = DICTIONARY[key];

//     const response = {
//         word: key,
//         definition: definition
//     };

//     res.json(response);
// });
app.get('/lookup/:key', function (req, res) {
    const key = req.params.key;
    const definition = DICTIONARY[key];

    const response = {
        word: key,
        definition: definition
    };

    res.json(response);
});
// test url: http://localhost:8080/lookup?key=여자

// === Ex 2: query param -> route param
// === Ex 2: GET -> POST
// app.get('/update', function (req, res) {
//     const word = decodeURI(req.query.word);
//     const definition = decodeURI(req.query.definition);

//     // update word in dictionary - add if not existed
//     DICTIONARY[word] = definition;

//     const response = {
//         message: `Updated word: ${word}`
//     };

//     res.json(response);
// });
app.post('/update/:word', function (req, res) { // no jsonParser in need (see line #12-13)
    const word = req.params.word;
    const definition = req.body.definition;

    // update word in dictionary - add if not existed
    DICTIONARY[word] = definition;

    const response = {
        message: `Updated word: ${word}`
    };

    res.json(response);
});

app.listen(8080, function () {
    console.log('Server started listening on port 8080!');
});